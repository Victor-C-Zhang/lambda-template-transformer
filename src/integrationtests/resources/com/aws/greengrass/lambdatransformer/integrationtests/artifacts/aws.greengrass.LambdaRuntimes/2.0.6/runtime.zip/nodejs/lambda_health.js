/* eslint-disable prefer-destructuring, import/no-dynamic-require, class-methods-use-this */
const encodingTypeJSON = require('aws-greengrass-common-js').encodingType.encodingTypeJSON;
const BackoffRetry = require('aws-greengrass-common-js').BackoffRetry;
const Try = require('./try');

class LambdaHealth {
    constructor(functionArn, logger, ipcClient, getErrObject, statusIntervalSeconds = 60) {
        this._functionArn = functionArn;
        this._ipc = ipcClient;
        this._ipcPostLambdaStatus = this._ipc.postLambdaStatus.bind(this._ipc);
        this.statusIntervalMillis = Math.floor(parseFloat(process.env.AWS_GREENGRASS_LAMBDA_STATUS_TIMEOUT_SECONDS || statusIntervalSeconds) * 1000);
        this.logger = logger;
        this.statusTimer = null;
        this.status = 'Up';
        this._getErrObject = getErrObject;
    }

    postLambdaStatus() {
        let encodedStatusTry;
        if (this.encodingType === encodingTypeJSON) {
            encodedStatusTry = Try.safeJsonStringify(this.status);
        } else {
            encodedStatusTry = Try.TryResult.newValue(this.status);
        }

        if (encodedStatusTry.error) {
            const err = new Error(`Error occurred while attempting to serialize status to JSON: ${encodedStatusTry.error.toString()}`);

            this.logger.error(`Failed to parse work result: ${encodedStatusTry.error}`);
            this._postStatusErr(err);

            return;
        }

        const errorCallback = (error) => {
            this.logger.error(`Encountered error during attempt to post lambda status: ${error}`);
        };

        const postStatusWithRetry = new BackoffRetry(this._ipcPostLambdaStatus, this, errorCallback, 50, 2, 500, 10, 3000, true).tryOrThrowError;
        postStatusWithRetry(this._functionArn, encodedStatusTry.value, this._postStatusCompleted.bind(this));
    }

    start() {
        this.statusTimer = setInterval(() => {
            this.postLambdaStatus();
        }, this.statusIntervalMillis);
    }

    stop() {
        this.logger.info('Stopping status handler...');
        clearInterval(this.statusTimer);
    }

    _postStatusErr(error) {
        const errorJsonTry = Try.safeJsonStringify(this._getErrObject(error));
        if (errorJsonTry.error) {
            this.logger.error(`Failed to post status error: ${errorJsonTry.error}`);
            throw errorJsonTry.error;
        }
    }

    _postStatusCompleted() {
    }
}

exports.LambdaHealth = LambdaHealth;
